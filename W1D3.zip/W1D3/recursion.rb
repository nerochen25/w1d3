def range(int1, int2)
  return [] if int2 == int1
  n = int1 + 1
  [int1] + range(n, int2)
end

def recursive_sum(arr)
  return 0 if arr.empty?
  arr.first + recursive_sum(arr[1..-1])
end

def iterative_sum(arr)
  sum = 0
  arr.each do |el|
    sum += el
  end
  sum
end

def exp_1(b, n)
  return 1 if n == 0
  b * exp_1(b, n - 1)
end

def exp_2(b, n)
  return 1 if n == 0
  return b if n == 1
  n.even? ? exp_2(b, n / 2) ** 2 : b * (exp(b, (n - 1) / 2) ** 2)
end

class Array
  def deep_dup
    result = []
    return result if result.length == self.length
    self.each do |el|
      if el.is_a?(Array)
        result << el.deep_dup
      else
        result << el
      end
    end
    result
  end
end


def fibonacci_iterative(n)
  return [1] if n == 1
  result = [1, 1]
  (n - 2).times { result << result[-2..-1].reduce(:+) }
  result
end

def fibonacci_recursive(n)
  return [1] if n == 1
  return [1, 1] if n == 2
  prev_elements = fibonacci_recursive(n - 1)
  prev_elements << prev_elements[-2..-1].reduce(:+)
end

def bsearch(array, target)
  middle_el = array[array.length/2]
  return 1 if middle_el == target
  if target < middle_el
    sub_array = array.slice(0...array.length/2)
  else
    sub_array = array.slice(array.length/2..-1)
  end
  
  if sub_array.length == 1 && sub_array.first != target ||
    bsearch(sub_array, target) == nil  
    nil
  else
    array.length/2 + bsearch(sub_array, target)
  end
end

def merge_sort(arr)
  return arr if arr.length <= 1
  first_half, second_half = arr[0...arr.length/2], arr[arr.length/2..-1]
  merge(merge_sort(first_half), merge_sort(second_half))
end

def merge(first_half, second_half)
  result = []
  until first_half.empty? || second_half.empty?
    if first_half.first < second_half.first
      result << first_half.shift
    elsif 
      result << second_half.shift
    end
  end
  result + first_half + second_half
end


























